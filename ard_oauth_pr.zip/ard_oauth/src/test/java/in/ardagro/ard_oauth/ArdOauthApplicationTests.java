package in.ardagro.ard_oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArdOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
