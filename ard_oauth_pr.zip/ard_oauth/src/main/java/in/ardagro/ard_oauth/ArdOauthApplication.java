package in.ardagro.ard_oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArdOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArdOauthApplication.class, args);
	}

}
