import {OAuthAgentConfiguration} from './lib'
import {CookieSerializeOptions} from 'cookie'

const useSsl = !!process.env.SERVER_CERT_P12_PATH;
const DAY_SECONDS =  60 * 60 * 24
export const config: OAuthAgentConfiguration = {
    
    // Host settings
    port: process.env.PORT || '8080',
    endpointsPrefix: '/oauth-agent',
    serverCertPath: process.env.SERVER_CERT_P12_PATH || '',
    serverCertPassword: process.env.SERVER_CERT_P12_PASSWORD || '',

    // Client settings
    clientID: process.env.CLIENT_ID || 'client',
    clientSecret: process.env.CLIENT_SECRET || 'clsec',
    redirectUri: process.env.REDIRECT_URI || 'http://127.0.0.1:3000/oauth/auth_code',
    postLogoutRedirectURI: process.env.POST_LOGOUT_REDIRECT_URI || 'http://www.example.local/',
    scope: process.env.SCOPE || 'openid',

    // Cookie related settings
    cookieNamePrefix: process.env.COOKIE_NAME_PREFIX || 'ardoauthagent',
    encKey: process.env.COOKIE_ENCRYPTION_KEY || '4e4636356d65563e4c73233847503e3b21436e6f7629724950526f4b5e2e4e50',
    trustedWebOrigins: [process.env.TRUSTED_WEB_ORIGIN || 'http://www.example.local'],
    corsEnabled: process.env.CORS_ENABLED ? process.env.CORS_ENABLED === 'true' : true,
    cookieOptions: {
        httpOnly: true,
        sameSite: true,
        secure: useSsl,
        domain: process.env.COOKIE_DOMAIN || 'localhost',
        path: process.env.COOKIE_BASE_PATH || '/',
        maxAge:DAY_SECONDS
    } as CookieSerializeOptions,

    // Authorization Server settings
    issuer: process.env.ISSUER || 'http://login.example.local:8443/oauth/v2/oauth-anonymous',
    authorizeEndpoint: process.env.AUTHORIZE_ENDPOINT || 'http://localhost:9000/oauth2/authorize',
    logoutEndpoint: process.env.LOGOUT_ENDPOINT || 'http://login.example.local:8443/oauth/v2/oauth-session/logout',
    tokenEndpoint: process.env.TOKEN_ENDPOINT || 'http://localhost:9000/oauth2/token',
    userInfoEndpoint: process.env.USERINFO_ENDPOINT || 'http://login.example.local:8443/oauth/v2/oauth-userinfo',
}
