
import {NextFunction, Request, Response} from 'express'
import { getATCookieName } from '../lib';
import { getIDCookieName } from '../lib/cookieName';
import { InvalidCookieException } from '../lib/exceptions';
import { decryptCookie } from '../lib/cookieEncrypter';
import {config} from '../config'

export default function cookieTokenHnadlingMiddleware(
    request: Request, response: Response, next: NextFunction) {
		console.log('\n\n### '+request.originalUrl+' ###\n\n');
		
		if (request.originalUrl.startsWith('/oauth/')) {
			// skip any /oauth routes
			next();
			return;
		} 
		const atCookieData = request.cookies ? request.cookies[getATCookieName()] : undefined;
		console.log('*** '+atCookieData);
		//const idCookieData = request.cookies ? request.cookies[getIDCookieName()] : undefined;
		if(atCookieData /*&& idCookieData*/){
			console.log('GOT REQUIRED COOKIES\n'+atCookieData+'\n');
			let accessToken = null
			try {
				accessToken = decryptCookie(config.encKey, atCookieData);
				request.headers['Authorization'] = 'Bearer '+accessToken
				console.log("\n**** RETRIVED DECRYPTED AT **** "+accessToken);
			} catch (err: any) {
				const error = new InvalidCookieException(err)
				error.logInfo = 'Unable to decrypt the access token cookie to get user info'
				throw error
			}

		} else {
			console.log('XX - DID NOT FOUND REQUIRED COOKIES');
			throw new InvalidCookieException();
			return;
		}
    	next();
}
