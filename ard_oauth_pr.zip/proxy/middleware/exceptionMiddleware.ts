
import {NextFunction, Request, Response} from 'express';
import {config} from '../config'
//import {getCookiesForUnset } from'../lib';
import {OAuthAgentException} from '../lib/exceptions'
import {UnhandledException} from '../lib/exceptions'
import {RequestLog} from './requestLog';
import { getCookiesForUnset } from '../lib/loginHandler';

export default function exceptionMiddleware(
    caught: any,
    request: Request,
    response: Response,
    next: NextFunction): void {

    const exception = caught instanceof OAuthAgentException ? caught : new UnhandledException(caught)
    
    if (!response.locals.log) {
        
        // For malformed JSON errors, middleware does not get created so write the whole log here
        response.locals.log = new RequestLog()
        response.locals.log.start(request)
        response.locals.log.addError(exception)
        response.locals.log.end(response)

    } else {

        // Otherwise just include error details in logs
        response.locals.log.addError(exception)
    }
    
    const statusCode = exception.statusCode
    const data = { code: exception.code, message: exception.message}
    
    // Send the error response to the client and remove cookies when the session expires
    response.status(statusCode)
    if (data.code === 'session_expired') {
        response.setHeader('Set-Cookie', getCookiesForUnset(config.cookieOptions, config.cookieNamePrefix))
    }
    response.status(statusCode).json(data);
}
/*
 * Unhandled promise rejections may not be caught properly
 * https://medium.com/@Abazhenov/using-async-await-in-express-with-node-8-b8af872c0016
 */
export function asyncCatch(fn: any): any {

    return (request: Request, response: Response, next: NextFunction) => {

        Promise
            .resolve(fn(request, response, next))
            .catch((e) => {
                const data = { code: 500, message: 'ERROR - '+e}
                response.send(data)
            })
    };
}