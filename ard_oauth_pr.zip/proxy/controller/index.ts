import LoginAuthCodeController from "./loginAuthCodeController";

export {
    LoginAuthCodeController
}