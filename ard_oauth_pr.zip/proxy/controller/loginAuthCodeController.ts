import * as express from 'express'
import {
    handleAuthorizationResponse,
    getTokenEndpointResponse,
    getCookiesForTokenResponse,
} from '../lib'
import { config } from '../config'
import { asyncCatch } from '../middleware/exceptionMiddleware';
import { createAuthorizationRequest } from '../lib/loginHandler';
import { getTempCodeVerifierCookie } from '../lib/pkce';
import { getTempCodeVerifierCookieName } from '../lib/cookieName';

class LoginAuthCodeController {
    public router = express.Router();
    constructor() {
        this.router.post('/login_url', asyncCatch(this.oauthLoginUrl));
        this.router.post('/auth_code', asyncCatch(this.startAuthCode));
    }
    
    //function to get url with pkce flow (with details like client,code_challenge,flow,etc.) 
    oauthLoginUrl = async (req: express.Request, res: express.Response) => {
        //TODO - get security -- when everything else works
        // const options = new ValidateRequestOptions()
        // options.requireCsrfHeader = false
        // validateExpressRequest(req, options)

        //request body for extra prameters can be added if needed
        const authorizationRequestData = createAuthorizationRequest(config/*, req.body*/);

        res.setHeader('Set-Cookie',
            getTempCodeVerifierCookie(authorizationRequestData.codeVerifier, authorizationRequestData.state, config.cookieOptions, config.cookieNamePrefix, config.encKey))
        res.status(200).json({
            authorizationRequestUrl: authorizationRequestData.authorizationRequestURL
        })
 
    }
    //function for handling second step of pkce login with code verifier
    startAuthCode = async (req: express.Request, res: express.Response) => {

        //TODO - get security -- when everything else works

        //const options = new ValidateRequestOptions()
        //options.requireCsrfHeader = false
        //validateExpressRequest(req, options)

        var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
        const data = await handleAuthorizationResponse(fullUrl);
        console.log('\n\n### data : '  +' ---'+data.code +' --- '+ data.state);
        let isLoggedIn = false;
        let handled = false;
        let csrfToken: string = '';

        if (data.code && data.state) {
            //NEEDED FOR CODE CHANLANGE
            const tempCodeVerifierCookie = req.cookies ? req.cookies[getTempCodeVerifierCookieName()] : undefined;
            const tokenResponse = await getTokenEndpointResponse(config, data.code, data.state, tempCodeVerifierCookie);
            /*
            CHECK IF WE WANT TO VALIDATE HERE OR AT BEnd 
            CHECK CSRF
        	
            if (tokenResponse.id_token) {
                validateIDtoken(config, tokenResponse.id_token)
            }
        	
            csrfToken = generateRandomString()
            const csrfCookie = req.cookies[getCSRFCookieName(config.cookieNamePrefix)]
            if (csrfCookie) {
                
                try {
                    // Avoid setting a new value if the user opens two browser tabs and signs in on both
                    csrfToken = decryptCookie(config.encKey, csrfCookie)

                } catch (e) {

                    // If the system has been redeployed with a new cookie encryption key, decrypting old cookies from the browser will fail
                    // In this case generate a new CSRF token so that the SPA can complete its login without errors
                    csrfToken = generateRandomString()
                }
            } else {

                // Generate a new value otherwise
                csrfToken = generateRandomString()
            }
        	
            */

            //////////////const cookiesToSet = getCookiesForTokenResponse(tokenResponse, config, true, csrfToken)
            console.log('tokenResponse: ' + tokenResponse);
            //////////////TODO -- csrf last pram in below call
            const cookiesToSet = getCookiesForTokenResponse(tokenResponse, config, true, '');
            console.log('cookiesToSet: ' + cookiesToSet);
            res.set('Set-Cookie', cookiesToSet)
            handled = true
            isLoggedIn = true

        }
        const responseBody = {
            handled,
            isLoggedIn,
        } as any
        res.status(200).json(responseBody)
    }
}

export default LoginAuthCodeController;