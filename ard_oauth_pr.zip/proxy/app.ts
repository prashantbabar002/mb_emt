import {
    LoginAuthCodeController
} from './controller';
import {config} from './config'
import exceptionMiddleware from './middleware/exceptionMiddleware';
import cookieParser from 'cookie-parser';
import cookieTokenHandlingMiddleware from './middleware/cookieTokenHandlingMiddleware';

const express = require("express");
const morgan = require("morgan");
const { createProxyMiddleware } = require("http-proxy-middleware");
import bodyParser from 'body-parser';
require("dotenv").config();

// Create Express Server
const app = express();

// Configuration
const PORT = 3000;
const HOST = "localhost";
//const { API_BASE_URL } = process.env;
//const { API_KEY_VALUE } = process.env;
const API_SERVICE_URL = `https://requestinspector.com/inspect/01h7ybpwnjndpsq0xnebg1z7fv`;

// Logging the requests
app.use(morgan("dev"));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(cookieParser())
app.use('*', express.json())
app.use('*',cookieTokenHandlingMiddleware);

app.use('*', exceptionMiddleware)


const controllers = {
    '/oauth': new LoginAuthCodeController(),
};

for (const [path, controller] of Object.entries(controllers)) {
	var endpointStartsWith = path === '/oauth'?path:config.endpointsPrefix + path;
	console.log(' ---endpointStartsWith --- '+endpointStartsWith );
    app.use(endpointStartsWith, controller.router);
}


// Proxy Logic : Proxy endpoints
app.use(
	"/",
	createProxyMiddleware({
		target: API_SERVICE_URL,
		changeOrigin: true,
		//pathRewrite: {
		//	"^/": "/posts/",
		//},
		//onProxyReq: (proxyReq, req, res) => {			 
		///	Object.keys(req.headers).forEach(function (key) {
		//		 console.log("H-----"+key+"    "+req.headers[key]);
		//	});
		//}
		
	})
);

// Starting our Proxy server
app.listen(PORT, HOST, () => {
	console.log(`Starting Proxy at ${HOST}:${PORT}`);
});
