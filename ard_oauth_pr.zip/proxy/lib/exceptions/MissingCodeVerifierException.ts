import OAuthAgentException from './OAuthAgentException'

export default class MissingCodeVerifierException extends OAuthAgentException {
    public statusCode = 400
    public code = 'invalid_request'

    constructor() {
        super("Missing code verifier when completing a login")
    }
}
