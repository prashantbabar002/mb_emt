
import {decryptCookie, getEncryptedCookie} from './cookieEncrypter'
import OAuthAgentConfiguration from './oauthAgentConfiguration';
import {CookieSerializeOptions, serialize} from 'cookie'
import { generateHash, generateRandomString } from './pkce';
import AuthorizationResponseException from './exceptions/AuthorizationResponseException';
import {default as urlparse} from 'url-parse'
import { MissingTempLoginDataException, OAuthAgentException } from './exceptions';
import InvalidStateException from './exceptions/InvalidStateException';
import AuthorizationServerException from './exceptions/AuthorizationServerException';
import { Grant } from './grant';
import AuthorizationClientException from './exceptions/AuthorizationClientException';

const DAY_MILLISECONDS = 1000 * 60 * 60 * 24
export async function handleAuthorizationResponse(pageUrl?: string): Promise<any> {

	const data = getUrlParts(pageUrl)

    if (data.state && data.code) {

        return {
            code: data.code,
            state: data.state,
        }
    }

    if (data.state && data.error) {

        throw new AuthorizationResponseException(
            data.error,
            data.error_description || 'Login failed at the Authorization Server')
    }

    return {
        code: null,
        state: null,
    }
}



function getUrlParts(url?: string): any {
    
    if (url) {
        const urlData = urlparse(url, true)
        if (urlData.query) {
            return urlData.query
        }
    }

    return {}
}

export async function getTokenEndpointResponse(config: OAuthAgentConfiguration, code: string, state: string, tempCodeVerifierCookie: string | undefined | null, ): Promise<any> {
	
    if (!tempCodeVerifierCookie) {
        return Promise.reject(new MissingTempLoginDataException())
    }

    const parsedTempLoginData = JSON.parse(decryptCookie(config.encKey, tempCodeVerifierCookie))
    console.log('\n\n\n DECRYPTED CODE VERIFIER --- '+JSON.stringify(parsedTempLoginData));
    
    if (parsedTempLoginData.state !== state) {
        return Promise.reject(new InvalidStateException())
    }

    try {
        var logingDetails = {
            ep: config.tokenEndpoint,
            method: 'POST',
            headers: {
                'Authorization': 'Basic ' + Buffer.from(config.clientID+ ":" + config.clientSecret).toString('base64'),
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'grant_type=authorization_code&redirect_uri=' + config.redirectUri 
            + '&code=' + code 
            + '&code_verifier=' + parsedTempLoginData.codeVerifier
            + '&client_id=' + config.clientID 
        };
        console.log('\n\n\n\n\n'+JSON.stringify(logingDetails));
        const res = await fetch(
            config.tokenEndpoint,
            {
                method: 'POST',
                headers: {
                    //'Authorization': 'Basic ' + Buffer.from(config.clientID+ ":" + config.clientSecret).toString('base64'),
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'grant_type=authorization_code'
                +'&redirect_uri='  + config.redirectUri 
                + '&code=' + code 
                + '&code_verifier=' + parsedTempLoginData.codeVerifier
                + '&client_id=' + config.clientID 
            });

        const text = await res.text()
        
        if (res.status >= 500) {
            const error = new AuthorizationServerException()
            error.logInfo = `Server error response in an Authorization Code Grant: ${text}`
            throw error
        }

        if (res.status >= 400) {
            throw new AuthorizationClientException(Grant.AuthorizationCode, res.status, text)
        }

        return JSON.parse(text)

    } catch (err: any) {

        if (!(err instanceof OAuthAgentException)) {
            const error = new AuthorizationServerException(err)
            error.logInfo = 'Connectivity problem during an Authorization Code Grant'
            throw error
        } else {
            throw err
        }
    }
    
    
    
    
    /*return {
        access_token: "eyJraWQiOiIzZGVmZjY4YS1lMjNkLTRlZDAtYmIwOS1mN2Q5MmM3NzlhZDMiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1IiwiYXVkIjoiY2xpZW50IiwibmJmIjoxNjkxNjgyMTk0LCJzY29wZSI6WyJvcGVuaWQiXSwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo5MDAwIiwiZXhwIjoxNjkxNjgyNDk0LCJpYXQiOjE2OTE2ODIxOTR9.ItgfCPImB_OEnX11C-2U68sFMEQEaLwvLse8vIW718tBY5kae5Hv-LaaM-CbNr5ddhpu0WSLUdFDUJvVOK28gbdCzDz6qU3MVV25Z3lXeb38wdNCfFH_CKD1KdJqZ617NwzH677F9VvCTaIjkq8GwcucVyUASqOmrls2Wp6qRNEFwhUdA0bdqyvJhZyEG5lkX97XeMQUXjHHMqFYfV8tUj_wRCZwjiXJN3e-_uq5O5ST5Tp5d6ht4-yGpG1gYFOF94OXSpFIm-zSt8B2broDwunIZWjX6IA1fFah2TPAHXkLD6c2AIcD12NZphxORwoRnVVTvZQ7fmSY6h6cOML3vA",
		scope: "openid",
		id_token: "eyJraWQiOiIzZGVmZjY4YS1lMjNkLTRlZDAtYmIwOS1mN2Q5MmM3NzlhZDMiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1IiwiYXVkIjoiY2xpZW50IiwiYXpwIjoiY2xpZW50IiwiYXV0aF90aW1lIjoxNjkxNjgyMDk1LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjkwMDAiLCJleHAiOjE2OTE2ODM5OTQsImlhdCI6MTY5MTY4MjE5NCwic2lkIjoiQ2FfWXZUWGxMTVZiV25jdHA3Y1VhbmlaQXY1ZExXdWYxU1NBOEszZlJ6NCJ9.B9gUuXZczMZ-3s1z-IfnUWVMGD1jymcfwr6pjDCQjD1P65le0KbyE_IUZqlTc59wa4yLoPkTmjIFuH1PKYo0F-kZmgdSh7YBjk8bAgENW6mIsE9gwCqctee4d7TXmx9KcJYjDXkqIiZaraBTmjlhhwBeeEbx-P19sOnnkXHdTePp_8OpyMczVJ9vnYUDvhFkYLakL0kStP7iQ_RkcWXfsi7FFP34mXJXVly749We-XniGc9q6i_HKFACYVae3Yfffo7OLu_NIMI7em_QEsqGkXVyDvWLu-BTidB7wLynJ1xVEOyfR73uQO5TocZu1oFkfujMmxQf24xKhLtCPinSJA",
		token_type: "Bearer",
		expires_in: 299
    }*/
}

export function getCookiesForTokenResponse(tokenResponse: any, config: OAuthAgentConfiguration, unsetTempLoginDataCookie: boolean = false, csrfCookieValue?: string): string[] {
    
    const cookies = [
        getEncryptedCookie(config.cookieOptions, tokenResponse.access_token, getCookieName('at',config), config.encKey)
    ]
/*
    if (csrfCookieValue) {
        cookies.push(getEncryptedCookie(config.cookieOptions, csrfCookieValue, getCSRFCookieName(config.cookieNamePrefix), config.encKey))
    }

    if (unsetTempLoginDataCookie) {
        cookies.push(getTempLoginDataCookieForUnset(config.cookieOptions, config.cookieNamePrefix))
    }
*/
    if (tokenResponse.refresh_token) {
        const refreshTokenCookieOptions = {
            ...config.cookieOptions,
            path: config.endpointsPrefix + '/refresh'
        }
        cookies.push(getEncryptedCookie(refreshTokenCookieOptions, tokenResponse.refresh_token, getCookieName('auth',config), config.encKey))
    }

    if (tokenResponse.id_token) {
        const idTokenCookieOptions = {
            ...config.cookieOptions,
            path: config.endpointsPrefix + '/claims'
        }
        cookies.push(getEncryptedCookie(idTokenCookieOptions, tokenResponse.id_token, getCookieName('id',config), config.encKey))
    }

    return cookies
}
function getCookieName(cookieName?: string,config?: OAuthAgentConfiguration){
	return (config?.cookieNamePrefix+'_'+cookieName);
}

export function getCookiesForUnset(options: CookieSerializeOptions, cookieNamePrefix: string): string[] {

    const cookieOptions = {
        ...options,
        expires: new Date(Date.now() - DAY_MILLISECONDS),
    }

    return [
        serialize(getCookieName('auth'), "", cookieOptions),
        serialize(getCookieName('at'), "", cookieOptions),
        serialize(getCookieName('id'), "", cookieOptions),
        serialize(getCookieName('csrf'), "", cookieOptions)
    ]
}

//class for auth request generation data
class AuthorizationRequestData {
    public readonly authorizationRequestURL: string
    public readonly codeVerifier: string
    public readonly state: string

    constructor(authorizationRequestURL: string, codeVerifier: string, state: string) {
        this.authorizationRequestURL = authorizationRequestURL
        this.codeVerifier = codeVerifier
        this.state = state
    }
} 

//function for generting oauth url 
//ClientOptions - can be added if needed
export function createAuthorizationRequest(config: OAuthAgentConfiguration, /*options?: ClientOptions*/): AuthorizationRequestData {

    const codeVerifier = generateRandomString();
    console.log('\n\n ====> code verifier: '+codeVerifier);
    const state = generateRandomString();

    let authorizationRequestUrl = config.authorizeEndpoint + "?" +
        "client_id=" + encodeURIComponent(config.clientID) +
        "&redirect_uri=" + encodeURIComponent(config.redirectUri) +
        "&response_type=code" +
        "&state=" + encodeURIComponent(state) +
        "&code_challenge=" + generateHash(codeVerifier) +
        "&code_challenge_method=S256"

        //options from req body can be added later - 
        //for now assume public client will send only needed params
        /*if (options && options.extraParams) {
        options.extraParams.forEach((p) => {
            if (p.key && p.value) {
                authorizationRequestUrl += `&${p.key}=${encodeURIComponent(p.value)}`
            }
        });
    }*/

    if (config.scope) {
        authorizationRequestUrl += "&scope=" + encodeURIComponent(config.scope)
    }

    return new AuthorizationRequestData(authorizationRequestUrl, codeVerifier, state)
}

