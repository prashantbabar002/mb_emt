import {config} from '../config'
const getTempCodeVerifierCookieName = (): string => getCookieName('temp_code_vrf');
const getAuthCookieName = (): string => getCookieName('auth');
const getATCookieName = (): string => getCookieName('at'); 
const getIDCookieName = (): string => getCookieName('id');
const getCSRFCookieName = (): string => getCookieName('csrf'); 
function getCookieName  (cookieSuffix: string){
    return config.cookieNamePrefix +'_'+ cookieSuffix;
}

export {getTempCodeVerifierCookieName, getATCookieName, getAuthCookieName, getIDCookieName, getCSRFCookieName}
