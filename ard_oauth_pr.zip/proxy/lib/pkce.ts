import * as crypto from 'crypto'
import {CookieSerializeOptions, serialize} from 'cookie'
import {getTempCodeVerifierCookieName} from './cookieName'
import {encryptCookie} from './cookieEncrypter'

const VALID_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
const DAY_MILLISECONDS = 1000 * 60 * 60 * 24

function generateRandomString(length = 64): string {
    const array = new Uint8Array(length)
    crypto.randomFillSync(array)
    const mappedArray = array.map(x => VALID_CHARS.charCodeAt(x % VALID_CHARS.length))
    return String.fromCharCode.apply(null, [...mappedArray])
}

function generateHash(data: string): string {
    const hash = crypto.createHash('sha256')
    hash.update(data)
    const hashedData = hash.digest('base64')

    return base64UrlEncode(hashedData)
}

function base64UrlEncode(hashedData: string): string {
    return hashedData
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
}

function getTempCodeVerifierCookie(codeVerifier: string, state: string, options: CookieSerializeOptions, cookieNamePrefix: string, encKey: string): string {
    return serialize(getTempCodeVerifierCookieName(), encryptCookie(encKey, JSON.stringify({ codeVerifier, state })), options)
}
/*
function getTempLoginDataCookieForUnset(options: CookieSerializeOptions, cookieNamePrefix: string): string {
    const cookieOptions = {
        ...options,
        expires: new Date(Date.now() - DAY_MILLISECONDS)
    }

    return serialize(getTempLoginDataCookieName(cookieNamePrefix), "", cookieOptions)
}
*/
export {generateHash, generateRandomString, getTempCodeVerifierCookie/*, getTempLoginDataCookieForUnset*/}
