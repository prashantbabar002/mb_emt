export enum Grant {
    AuthorizationCode,
    UserInfo,
    RefreshToken,
}
